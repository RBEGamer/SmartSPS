#include "node_nbdo.h"







node_nbdo::node_nbdo(int id)
{
	nid = id;
}

node_nbdo::~node_nbdo()
{
}

void node_nbdo::update(float timestep)
{
	if (node_nbdo::updated_values) {
		node_nbdo::updated_values = false;
		//logic machen

		if (node_nbdo::p0_value_input_state) {
			//SEND TO SERIAL SEND QUARRY -> PORT HIGH
		}
		else {
			//SEND TO SERIAL SEND QUARRY -> PORT LOW
		}

		//hier sonst alle weitren node durchgehen //f�r alle nodes di einen ausgansnode besitzen
		for (size_t i = 0; i < sizeof(connectons); i++){
			connectons[i].connector_node_ptr->updated_values = true;
			}
	}
}

void node_nbdo::init()
{
}

void node_nbdo::load_node_parameters(char params[])
{
	//WIRTE SPLIT FUNKTION TO ADD PARAMETERS TO FUNKTION
}
void node_nbdo::set_value(int position, float value)
{
	bool uv = true;
	switch (position)
	{
	case 0: if (value > 0.0f) { p0_value_input_state = true; }else { p0_value_input_state = false; } break;
	default:uv = true; break;
	}
	updated_values = uv;
}

void node_nbdo::set_value(int position, int value)
{
	bool uv = true;
	switch (position)
	{
	case 0: if (value > 0) { p0_value_input_state = true; }
			else { p0_value_input_state = false; } break;
	default:uv = true; break;
	}
	updated_values = uv;
}

void node_nbdo::set_value(int position, bool value)
{
	bool uv = true;
	switch (position)
	{
	case 0:  p0_value_input_state = value;  break;
	default:uv = true; break;
	}
	updated_values = uv;
}

void node_nbdo::set_value(int position, std::string value)
{
	bool uv = true;
	switch (position)
	{
	case 0: if (value != "") { p0_value_input_state = true; }
			else { p0_value_input_state = false; } break;


	default:uv = true; break;
	}
	updated_values = uv;
}

float node_nbdo::get_value_f(int position)
{
	switch (position)
	{
	case 0:if (p0_value_input_state) { return 1.0f; }
		   else { return 0.0f; } break;
	default:
		return -1.0f;
		break;
	}
}

int node_nbdo::get_value_i(int position)
{
	switch (position)
	{
	case 0:if (p0_value_input_state) { return 1; }
		   else { return 0; } break;
	default:
		return -1;
		break;
	}
}

bool node_nbdo::get_value_b(int position)
{
	switch (position)
	{
	case 0:return p0_value_input_state; break;
	default:
		return -1.0f;
		break;
	}
}

std::string node_nbdo::get_value_s(int position)
{
	switch (position)
	{
	case 0:if (p0_value_input_state) { return "TRUE"; }
		   else { return "FALSE"; } break;
	default:
		return "FALSE";
		break;
	}
}
