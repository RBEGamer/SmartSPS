#pragma once
//include the main base node class
#include "base_node.h"
//include the
#include "node_nbdi.h"
#include "node_nbdo.h"