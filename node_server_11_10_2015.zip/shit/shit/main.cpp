#include <iostream>
#include <ctime> //timer class 
#include "main_node_include.h"
using namespace std;

int main(int argc, char *argv[])
{
	float delta_time = 0.0f; //current updatetime in loop
	bool break_update_cycle = true; //if false the programm exits
	
	//NID		NSI		CON			PARAM
	//	1		NBDI	1:0:2:0		GPIO1 %
	//	2		NBDO					GPIO2%


	//	globaler trenner %
	//	trenner zwischen eintr�gen :

	
	std::cout << "NODESERVER V1.2 STARTING" << std::endl;

	//CREATE NODE BUFFER ARRAY
	base_node* nodes_buffer[2]; //<- AMOUNT OF NODES IN ONE SCHEMATIC DB TABLE
	//CREATE NODE INSTANCES WITH THE SPCIFIC ID
	nodes_buffer[0] = new node_nbdi(1); //<- NID
	nodes_buffer[1] = new node_nbdo(2);
	//LOAD PARAMETERS TO INSTANCES
	nodes_buffer[0]->load_node_parameters("GPIO1%"); //<- DB PARAMS
	nodes_buffer[1]->load_node_parameters("GPIO1%");
	//MAKE CONNECTION TO INSTANCES
	std::cout << sizeof(nodes_buffer) << " NODES LOADED" << std::endl;


	std::cout << "STARTING MAIN UPDATE LOOP" << std::endl;
	while (break_update_cycle)
	{
		clock_t begin = clock();//store thickcount before processing though the nodes
	

		for (int i = 0; i < 2; i++)
		{
			if (nodes_buffer[i]->enabled && nodes_buffer[i]->nid >= 0) {
				nodes_buffer[i]->update(delta_time);
			}
		}
		//cout << delta_time << endl;
		clock_t end = clock(); //store tickcount after processing thought all actives nodes
		delta_time = float(end - begin); //geht the final frametime to use it in the next update cycle
	}
	std::cout << "LEAVING MAIN UPDATE LOOP" << std::endl;
	//nodes einlesen
	//array per anzahl erstellen
	//nodes erstellen
	//alle nodes enaben
	//alle nodes updaten mit dem bool
	//alles nodes mit updatentime versorgen
	std::cout << "EXIT NODESERVER WITH EXITCODE 0" << std::endl;
	return 0;
}