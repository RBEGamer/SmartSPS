#include "node_nbdo.h"






//CASTEN !!!!!!! WEN TYP UNTERSHCIEDLICH
void node_nbdo::set_value(int position, float value)
{
}

void node_nbdo::set_value(int position, int value)
{
}

void node_nbdo::set_value(int position, bool value)
{
}

void node_nbdo::set_value(int position, std::string value)
{
}

float node_nbdo::get_value_f(int position)
{
	return 0.0f;
}

int node_nbdo::get_value_i(int position)
{
	return 0;
}

bool node_nbdo::get_value_b(int position)
{
	return false;
}

std::string node_nbdo::get_value_s(int position)
{
	return std::string();
}
